package com.hridoykrisna.stdapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StandardRestApiAndSecurityApplicationTests {

    @Test
    void contextLoads() {
    }

}
