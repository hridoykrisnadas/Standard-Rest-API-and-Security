package com.hridoykrisna.stdapi.service.IMPL;

import com.hridoykrisna.stdapi.model.User;
import com.hridoykrisna.stdapi.repository.UserRepo;
import com.hridoykrisna.stdapi.service.UserService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("userService")
public class UserServiceIMPL implements UserService {
    private UserRepo userRepo;
    public UserServiceIMPL(UserRepo userRepo){
        this.userRepo = userRepo;
    }
    @Override
    public User save(User user) {
        return userRepo.save(user);
    }

    @Override
    public User update(Long Id, User user) {
        User user1 = userRepo.findByIdIsActiveTrue(Id);
        if (user1!=null){
            user.setId(Id);
            userRepo.save(user);
        }

        return null;
    }

    @Override
    public String delete(Long Id) {
        User user1 = userRepo.findByIdIsActiveTrue(Id);
        if (user1!=null){
            user1.setIsActive(false);
            userRepo.save(user1);
        }
        return null;
    }

    @Override
    public User getById(Long Id) {
        User user1 = userRepo.findByIdIsActiveTrue(Id);
        if (user1!=null){
            return user1;
        }
        return null;
    }

    @Override
    public User getByUsername(String username) {
        return userRepo.findByUsernameIsActiveTrue(username);
    }

    @Override
    public List<User> getAllUser() {
        return userRepo.findAll();
    }
}
